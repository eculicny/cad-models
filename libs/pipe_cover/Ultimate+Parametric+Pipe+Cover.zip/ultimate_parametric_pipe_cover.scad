// Ultimate Parametric Pipe Cover by Velko Valnarov

/* [View] */
disassemble = true;

/* [Body] */
shape = "round";         // [round:round, square:square]
corner_radius = 5;       // [0.00:0.1:50.00]
type = "single";         // [single:single, double:double]
pipe_distance = 45;      // [30.00:0.1:175.00]
height = 6;              // [5.00:0.1:25.00]
outer_size = 50;         // [25.00:0.1:100.00]
hole_diameter = 15;      // [5.00:0.1:50.00]
edge_type = "chamfer";   // [chamfer:chamfer, fillet:fillet, fillet_inward:fillet_inward, step:step]
edge_size = 2;           // [0.00:0.1:10.00]

/* [Collar] */
enable_collar = true;
collar_shape = "round";   // [round:round, square:square]
collar_corner_radius = 5; // [0.00:0.1:50.00]
collar_layout = "merged"; // [merged:merged, separate:separate]
collar_size = 25;         // [0.00:0.1:100.00]
collar_height = 2;        // [0.00:0.1:25.00]
collar_edge_type = "chamfer"; // [chamfer:chamfer, fillet:fillet, fillet_inward:fillet_inward, step:step]
collar_edge_size = 1;    // [0.00:0.1:10.00]

/* [Joint] */
joint_type = "dovetail"; // [dovetail:dovetail, complex:complex]
peg_width = 8;           // [5.00:0.1:20.00]
peg_length = 6;          // [5.00:0.1:10.00]
peg_height = 3;          // [2.00:0.1:10.00]
tolerance = 0.10;        // [0.00:0.01:1.00]

/* [Hidden] */
$fn = 150;
hole_chamfer = 2;
groove_extra_depth = 1.0;
groove_extra_height = 0.5;
peg_chamfer = 0.75;
peg_chamfer_top = 0.5;
peg_chamfer_bottom = 0.5;
peg_lock_height = 1.0;

// --- Calculations ---
peg_lock_size = tolerance + 0.2;
peg_z_offset = height / 2 - peg_height / 2;
peg_inner_width = peg_width + 4;
max_split_distance = outer_size / 4;
radius_inner = hole_diameter / 2;
radius_outer = outer_size / 2;
radius_collar = collar_size / 2;
radius_middle = (radius_inner + radius_outer) / 2; 

total_height = enable_collar ? max(height, collar_height + height) : height;
current_distance = disassemble ? max_split_distance / 2 : 0;

peg_xs = (type == "double") 
    ? [(pipe_distance/2) + radius_middle, 0, -((pipe_distance/2) + radius_middle)] 
    : [radius_middle, -radius_middle];

offsets = (type == "double") ? [-pipe_distance/2, pipe_distance/2] : [0];

// --- Helper Modules ---
module edge_cutout(type, size) {
    if (type == "chamfer") 
        polygon([[-0.1, size + 0.1], [size + 0.1, -0.1], [size + 0.1, size + 0.1]]);
    else if (type == "fillet") 
        difference() { square([size + 0.1, size + 0.1]); circle(r = size); }
    else if (type == "fillet_inward") 
        translate([size, size]) circle(r = size);
    else if (type == "step") 
        square([size + 0.1, size + 0.1]);
}

module cut_cube() {
    max_d = enable_collar ? max(outer_size, collar_size) : outer_size;
    w = (type == "double") ? pipe_distance + max_d + 10 : max_d + 10;
    translate([-w, 0, -1]) cube([w * 2, max_d + 10, total_height + 2]);
}

module rounded_rect_solid(X, Y, h, safe_r) {
    if (safe_r > 0.01) {
        hull() {
            for(dx=[-1,1], dy=[-1,1]) {
                translate([dx*(X/2 - safe_r), dy*(Y/2 - safe_r), 0])
                    cylinder(r=safe_r, h=h);
            }
        }
    } else {
        translate([0,0,h/2]) cube([X, Y, h], center=true);
    }
}

module edge_cutter_tool(X, Y, h, safe_r, e_type, e_size) {
    module cutter_profile() { edge_cutout(e_type, e_size); }

    translate([0, 0, h - e_size]) {
        if (safe_r > 0.01) {
            for(dx=[-1,1], dy=[-1,1]) {
                rot = (dx>0 && dy>0) ? 0 : (dx<0 && dy>0) ? 90 : (dx<0 && dy<0) ? 180 : 270;
                translate([dx*(X/2 - safe_r), dy*(Y/2 - safe_r), 0])
                    rotate([0,0,rot])
                    rotate_extrude(angle=90)
                        translate([safe_r - e_size, 0, 0]) cutter_profile();
            }
        }

        len_x = X - 2*safe_r;
        len_y = Y - 2*safe_r;

        if (len_x > 0.01) {
            translate([0, Y/2 - e_size, 0])
                rotate([0,0,90]) rotate([90,0,0])
                linear_extrude(height=len_x, center=true) cutter_profile();
            translate([0, -(Y/2 - e_size), 0])
                rotate([0,0,-90]) rotate([90,0,0])
                linear_extrude(height=len_x, center=true) cutter_profile();
        }
        if (len_y > 0.01) {
            translate([X/2 - e_size, 0, 0])
                rotate([0,0,0]) rotate([90,0,0])
                linear_extrude(height=len_y, center=true) cutter_profile();
            translate([-(X/2 - e_size), 0, 0])
                rotate([0,0,180]) rotate([90,0,0])
                linear_extrude(height=len_y, center=true) cutter_profile();
        }
    }
}

module solid_block_with_edge(X, Y, h, e_type, e_size, c_radius) {
    eff_r = (c_radius > 0) ? max(c_radius, e_size + 0.001) : 0;
    safe_r = min(eff_r, X/2, Y/2);

    if (e_size > 0) {
        difference() {
            rounded_rect_solid(X, Y, h, safe_r);
            edge_cutter_tool(X, Y, h, safe_r, e_type, e_size);
        }
    } else {
        rounded_rect_solid(X, Y, h, safe_r);
    }
}

// --- Structural Layout Helpers ---
module pill_layout(dist) {
    translate([-dist/2, 0, 0]) rotate_extrude() children();
    translate([dist/2, 0, 0]) rotate_extrude() children();
    rotate([90, 0, 0]) rotate([0, 90, 0])
        linear_extrude(height = dist, center = true)
        union() {
            children();
            mirror([1, 0, 0]) children();
        }
}

// --- Base Modules ---
module base_profile() {
    difference() {
        square([radius_outer, height]);
        translate([radius_outer - edge_size, height - edge_size])
            edge_cutout(edge_type, edge_size);
    }
}

module collar_profile() {
    total_c_height = collar_height + height;
    difference() {
        square([radius_collar, total_c_height]);
        translate([radius_collar - collar_edge_size, total_c_height - collar_edge_size])
            edge_cutout(collar_edge_type, collar_edge_size);
    }
}

module render_base_geometry() {
    if (shape == "round") {
        if (type == "double") pill_layout(pipe_distance) base_profile();
        else rotate_extrude() base_profile();
    } else {
        X_base = (type == "double") ? pipe_distance + outer_size : outer_size;
        solid_block_with_edge(X_base, outer_size, height, edge_type, edge_size, corner_radius);
    }
}

module render_collar_geometry() {
    if (collar_shape == "round") {
        if (type == "double") {
            if (collar_layout == "merged") pill_layout(pipe_distance) collar_profile();
            else { 
                translate([-pipe_distance/2, 0, 0]) rotate_extrude() collar_profile();
                translate([pipe_distance/2, 0, 0]) rotate_extrude() collar_profile();
            }
        } else {
            rotate_extrude() collar_profile();
        }
    } else {
        if (type == "double") {
            if (collar_layout == "merged") {
                solid_block_with_edge(pipe_distance + collar_size, collar_size, collar_height + height, collar_edge_type, collar_edge_size, collar_corner_radius);
            } else { 
                translate([-pipe_distance/2, 0, 0]) solid_block_with_edge(collar_size, collar_size, collar_height + height, collar_edge_type, collar_edge_size, collar_corner_radius);
                translate([pipe_distance/2, 0, 0]) solid_block_with_edge(collar_size, collar_size, collar_height + height, collar_edge_type, collar_edge_size, collar_corner_radius);
            }
        } else {
            solid_block_with_edge(collar_size, collar_size, collar_height + height, collar_edge_type, collar_edge_size, collar_corner_radius);
        }
    }
}

module base_body() {
    difference() {
        union() {
            render_base_geometry();
            
            if (enable_collar && collar_size > hole_diameter && (collar_height + height) > 0) {
                render_collar_geometry();
            }
        }

        for (offset_x = offsets) {
            translate([offset_x, 0, -1]) cylinder(h = total_height + 2, r = radius_inner);
            if (hole_chamfer > 0) {
                translate([offset_x, 0, -0.1]) 
                    cylinder(h = hole_chamfer + 0.1, r1 = radius_inner + hole_chamfer + 0.1, r2 = radius_inner);
            }
        }
    }
}

// --- Peg Modules ---
module pegs_complex(current_tolerance = 0, is_cutout = false) {
    overlap = 0.1;
    size_x = peg_width + current_tolerance * 2; 
    
    extra_y = is_cutout ? groove_extra_depth : 0;
    size_y = peg_length + current_tolerance + extra_y + overlap; 
    
    size_z = peg_height + current_tolerance * 2 + overlap * 2;
    z_pos = peg_z_offset - current_tolerance - overlap;
    
    apply_chamfer = !is_cutout;
    c_tip = apply_chamfer ? min(peg_chamfer, size_x / 2 - 0.01, size_z / 2 - 0.01, size_y - 0.01) : 0;
    c_top = apply_chamfer ? min(peg_chamfer_top, size_x / 2 - 0.01, size_z / 2 - 0.01) : 0;
    c_bot = apply_chamfer ? min(peg_chamfer_bottom, size_x / 2 - 0.01, size_z / 2 - 0.01) : 0;

    y_scale = is_cutout ? -1 : 1;

    for (px = peg_xs) {
        translate([px, 0, z_pos]) scale([1, y_scale, 1]) translate([-size_x / 2, -size_y + overlap, 0]) {
            union() {
                intersection() {
                    if (c_tip > 0) {
                        hull() {
                            translate([0, c_tip, 0]) cube([size_x, size_y - c_tip, size_z]);
                            translate([c_tip, 0, c_tip]) cube([size_x - 2*c_tip, 0.01, size_z - 2*c_tip]);
                        }
                    } else cube([size_x, size_y, size_z]);

                    if (c_top > 0 || c_bot > 0) {
                        hull() {
                            translate([0, 0, c_bot]) cube([size_x, size_y, size_z - c_top - c_bot]);
                            if (c_bot > 0) translate([c_bot, 0, 0]) cube([size_x - 2*c_bot, size_y, 0.01]);
                            if (c_top > 0) translate([c_top, 0, size_z - 0.01]) cube([size_x - 2*c_top, size_y, 0.01]);
                        }
                    } else cube([size_x, size_y, size_z]);
                }

                if (peg_lock_size > 0 && !is_cutout) {
                    bx = peg_lock_size + current_tolerance;
                    by = peg_lock_size * 2.5 + current_tolerance * 2; 
                    bz = peg_lock_height + current_tolerance * 2;     
                    dist_from_base = peg_length * (1/2); 
                    y_lock = size_y - overlap - dist_from_base;
                    z_lock = (size_z / 2) - (bz / 2);
                    
                    if (bz > 0) {
                        translate([size_x, y_lock - by/2, z_lock])
                            linear_extrude(bz) polygon([[0,0], [bx, by/2], [0, by]]);
                        translate([0, y_lock - by/2, z_lock])
                            linear_extrude(bz) polygon([[0,0], [-bx, by/2], [0, by]]);
                    }
                }
            }
        }
    }
}

module pegs_dovetail(current_tolerance = 0, is_cutout = false) {
    overlap = 0.1;
    size_x_base = peg_width + current_tolerance * 2; 
    size_x_tip = peg_inner_width + current_tolerance * 2;
    size_y = peg_length + current_tolerance + overlap; 
    
    extra_z = is_cutout ? groove_extra_height : 0;
    size_z = peg_height + current_tolerance * 2 + overlap * 2 + extra_z;
    
    z_pos = is_cutout ? -extra_z : 0; 

    c = is_cutout ? 0 : peg_chamfer_top;
    ext_y = overlap + c + 0.1;
    
    oversize_x_base = size_x_base - (size_x_tip - size_x_base) * (ext_y / size_y);

    poly = [
        [-oversize_x_base / 2, ext_y],
        [oversize_x_base / 2, ext_y],
        [size_x_tip / 2, -size_y],
        [-size_x_tip / 2, -size_y]
    ];

    for (px = peg_xs) {
        y_scale = is_cutout ? -1 : 1; 
        translate([px, 0, z_pos]) scale([1, y_scale, 1]) {
            if (c > 0) {
                hull() {
                    linear_extrude(height = size_z - c) polygon(poly);
                    translate([0, 0, size_z - 0.01])
                        linear_extrude(height = 0.01)
                        offset(delta = -c) polygon(poly);
                }
            } else {
                linear_extrude(height = size_z) polygon(poly);
            }
        }
    }
}

module pegs(current_tolerance = 0, is_cutout = false) {
    if (joint_type == "complex") pegs_complex(current_tolerance, is_cutout);
    else pegs_dovetail(current_tolerance, is_cutout);
}

// --- Generate Parts ---
module collar_half_male() {
    difference() {
        union() {
            intersection() { base_body(); cut_cube(); }
            intersection() { base_body(); pegs(0, false); }
        }
    }
}

module collar_half_female() {
    difference() {
        intersection() { base_body(); cut_cube(); }
        pegs(tolerance, true);
    }
}

color("wheat") translate([0, current_distance, 0]) collar_half_male();
color("wheat") translate([0, -current_distance, 0]) rotate([0, 0, 180]) collar_half_female();